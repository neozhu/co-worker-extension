## Privacy Policy
- This extension does not collect any user data
- This extension does not sync any data to any remote server
- This extension does not monitor the user